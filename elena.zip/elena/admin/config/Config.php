<?php

define('baseurl','http://localhost/elena/public');